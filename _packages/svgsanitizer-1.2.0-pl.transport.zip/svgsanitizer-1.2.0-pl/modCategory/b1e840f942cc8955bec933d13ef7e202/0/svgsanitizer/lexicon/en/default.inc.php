<?php
/**
 * Lexicon entries for svgSanitizer
 *
 * @package svgsanitizer
 * @subpackage lexicon
 */
