<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'The MIT License (MIT)

Copyright (c) 2017 Hugo Peek | Fractal Farming

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.',
    'readme' => '# svgSanitizer

A MODX extra to sanitize SVG files and parse them inline, or as part of an SVG sprite. The file is cleaned first to make sure there are no malicious scripts, links or other XSS tricksters inside. After that, you can tweak the output to match any compatibility or design requirements you may have.

Many thanks to Daryll Doyle for providing and maintaining the sanitizer:
https://github.com/darylldoyle/svg-sanitizer/

## Inline usage

To get started, place your SVGs in a folder inside your project and reference the file path in the svgSanitize snippet call:

```
[[svgSanitize?
    &file=`assets/img/icons/sanitize-me.svg`
    &title=`Add a title here for improved accessibility`
]]
```

## Create an SVG sprite

In addition to cleaning your SVG, you can choose to output the result as a symbol, for use in an SVG sprite:

```html
<svg class="hidden">
    [[svgSanitize?
        &file=`assets/img/icons/sanitize-me.svg`
        &title=`Add a title here for improved accessibility`
        &toSymbol=`1`
    ]]
    ...
</svg>
```

Will result in something like:

```html
<svg class="hidden">
    <symbol viewBox="0 0 24 24" id="sanitize-me">
        <title>Yay, you cared about accessibility</title>
        ...
    </symbol>
    ...
</svg>
```

Include this SVG somewhere in your HTML and then reference the symbols in your content like this:

```html
<svg>
    <use xlink:href="[[~[[*id]]? &scheme=`full`]]#sanitize-me"></use>
</svg>
```

Note that you have to prepend the anchor with the full URI. This is because MODX pages use the base element `<base href="https://your-site.com/">`, which confuses the anchor link inside the `<use>` element in some browsers.

Read more about that here: https://stackoverflow.com/questions/18259032/

## Caching

The sanitized SVGs are cached inside a sub folder of core/cache, based on the cacheKey setting. By default, this will be `svgsanitizer`. But please note:

> [!NOTE]
> **The default \'svgsanitizer\' cache folder is not cleared automatically!**

If you want to clear the SVG cache every time the MODX cache is cleared, you could simply change the cacheKey to \'default\'. But I don\'t recommend this. There\'s really no need to sanitize each SVG again after a cache clear.

A better option is to install [getCache](https://extras.modx.com/package/getcache) and create a menu button for manually clearing the \'svgsanitizer\' partition. Here\'s an example handler:

```js
var partition = \'svgsanitizer\';
var topic = \'/getcache/cache/partition/refresh/\' + partition;

this.console = MODx.load({
    xtype: \'modx-console\',
    register: \'mgr\',
    topic: topic,
    show_filename: 0
});

this.console.show(Ext.getBody());

MODx.Ajax.request({
    url: MODx.config.assets_url + \'components/getcache/connector.php\',
    params: {
        action: \'cache/partition/refresh\',
        partitions: partition,
        register: \'mgr\',
        topic: topic
    },
    listeners: {
        \'success\': {
            fn: function () {
                this.console.fireEvent(\'complete\');
            }, scope: this
        }
    }
});

return false;
```

You could place this under the regular Clear Cache button for example. Attach the `empty_cache` permission to grant the same access as for regular cache clearing.

## Properties

For the svgSanitize snippet.

Name | Description | Default
--- | --- | ---
file | The path to your SVG file. Can be absolute, or relative to your project root folder. |
title | Add a title that describes the content of the SVG graphic. This is important for people using screen readers. |
classes | Add one or more class names to the SVG tag. Only applies if used inline. |
stripFill | Remove inline fill colors from file. Enable this if you want to control fill color with CSS, i.e. for icons. | 0
stripStroke | Remove inline stroke colors from file. Same thing. | 0
minify | Removes unneeded spaces and line breaks. | 1
inline | By default, the snippet strips the XML header and some attributes from your SVG file that are not needed for inline display. But if you are planning to use your SVG as stand-alone file, then you probably want to keep those elements in. | 1
removeRemote | See: https://github.com/darylldoyle/svg-sanitizer/#remove-remote-references | 0
cacheKey | Sanitized SVGs will be cached inside this subfolder of core/cache. | svgsanitizer
cacheExpires | By default, the generated SVGs are cached for 1 year. You can change this to 1 for example, if you don\'t want it to cache anything during testing. | 86400*365
a11y | If accessibility is not a requirement, or if you already have that covered inside your SVG, you can disable this feature by setting it to 0. | 1

## Why

SVGs are a perfect way for delivering sharp and scalable graphics on your site. And serving them inline makes them even more versatile! You can change the colors of individual paths, let the SVG adapt to its parent\'s fill color or animate the contents with JS.

An added bonus for including SVGs with the svgSanitize snippet, is that you can actually use MODX syntax inside your SVGs. Create multilanguage SVGs by using lexicon strings as text, or use them in getResources templates with unique pagetitles or TV data... Endless possibilities.

Have fun!

## References

Some interesting resources about working with SVG:

- https://css-tricks.com/pretty-good-svg-icon-system/
- https://24ways.org/2014/an-overview-of-svg-sprite-creation-techniques/
- https://medium.com/@webprolific/why-and-how-i-m-using-svg-over-fonts-for-icons-7241dab890f0
- https://nucleoapp.com/how-to-create-an-icon-system-using-svg-symbols/
- https://css-tricks.com/svg-use-with-external-reference-take-2/
- https://codepen.io/NathanPJF/full/GJObGm
- https://www.sarasoueidan.com/blog/svgo-tools/
- https://jakearchibald.github.io/svgomg/
',
    'changelog' => '# Changelog for svgSanitizer

## svgSanitizer 1.2.0
Released on January 3, 2025

- Require PHP 8
- Update svg-sanitize to 0.20.0
- Clarify caching behaviour in readme
- Add system settings for changing cache key and expiry
- Add width and height to SVG based on viewBox

## svgSanitizer 1.1.0
Released on February 24, 2023

- Better error handling
- Better detection of changes in file, to force a cache refresh
- Remove aria-labelledby attribute (with possibly empty ID)
- Add ability to attach classes to SVG tag
- Add options to strip fill / stroke tags from SVG
- Update svg-sanitize to 0.15.4

## svgSanitizer 1.0.0
Released on June 29, 2017

Initial release',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '37f7a459e9a2d2a3e6bc3f87da97b142',
      'native_key' => 'svgsanitizer',
      'filename' => 'modNamespace/909e46f8c85498c9962caa06705e8491.vehicle',
      'namespace' => 'svgsanitizer',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c60028259e069f38c21460447de7d141',
      'native_key' => 'svgsanitizer.cache_key',
      'filename' => 'modSystemSetting/3f5ba6ef6e4249a25bb3de9b0fd0b68f.vehicle',
      'namespace' => 'svgsanitizer',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '655f5078eb7120a6f03c1767001f36d3',
      'native_key' => 'svgsanitizer.cache_expires',
      'filename' => 'modSystemSetting/c4dc4269c38eb1ab4a886106ca495ba6.vehicle',
      'namespace' => 'svgsanitizer',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '71657ce3bf5c8ee45dda64c89b90780b',
      'native_key' => NULL,
      'filename' => 'modCategory/b1e840f942cc8955bec933d13ef7e202.vehicle',
      'namespace' => 'svgsanitizer',
    ),
  ),
);